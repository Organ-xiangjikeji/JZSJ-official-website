# -*- coding: utf-8 -*-
 
# Copyright (c) 2017 - 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#
 
"""
Package containing the various interface extension plug-ins.
"""
